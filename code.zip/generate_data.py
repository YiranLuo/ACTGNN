import numpy as np
import matplotlib.pyplot as plt

# Function to generate centroids matrix M
def generate_centroids_matrix(K, J):
    centroids_matrix = np.random.rand(K, J)
    centroids_matrix = centroids_matrix * 10
    return centroids_matrix

# Function to generate assignments matrix A
def generate_assignments_matrix(I, K):
    random_indices = np.random.choice(K, size=I)
    assignment_matrix = np.zeros((I, K))
    assignment_matrix[np.arange(I), random_indices] = 1
    return assignment_matrix

# Function to generate the approximation of data matrix X_approx
def generate_data_matrix_approx(I, J, K):
    centroids_matrix = generate_centroids_matrix(K=K, J=J)
    assignments_matrix = generate_assignments_matrix(I=I, K=K)
    return np.dot(assignments_matrix, centroids_matrix), centroids_matrix
    
# Function to generate both data matrix and centroids matrix
def generate_data_matrix_and_centroids_matrix(I, J, K, noise_mean=0.0, noise_std_dev=0.3):
    data_matrix_approx, centroids_matrix = generate_data_matrix_approx(I=I, J=J, K=K)
    
    # Add Gaussian noise
    noise = np.random.normal(noise_mean, noise_std_dev, size=data_matrix_approx.shape)
    return data_matrix_approx + noise, centroids_matrix

# Function to generate synthetic data
def generate_data_all(I, J, K, size):
    input = []
    output = []
    for i in range(size):
        data_matrix, centroids_matrix = generate_data_matrix_and_centroids_matrix(I, J, K)
        # TO DO: Add different variance to the same set of matrix

        data_matrix = data_matrix.flatten()
        centroids_matrix = centroids_matrix.flatten()

        input.append(data_matrix)
        output.append(centroids_matrix)
    
    input_array = np.array(input)
    output_array = np.array(output)

    return input_array, output_array