import numpy as np
import torch
import torch.nn as nn
import generate_data
import MLP_model
import matplotlib.pyplot as plt
from torch.utils.data import TensorDataset, random_split, DataLoader

I = 50
J = 2
K = 5

# Generate data for training and testing
input_array, output_array = generate_data.generate_data_all(I, J, K, size=10000)

# Turn data type from double to float32
input_array = input_array.astype(np.float32)
output_array = output_array.astype(np.float32)

# Create input and output tensors from arrays 
input_tensor = torch.tensor(input_array)
output_tensor = torch.tensor(output_array)

train_proportion = 0.8

# Calculate number of samples for training and testing
num_samples = input_tensor.shape[0]
num_train_samples = int(train_proportion * num_samples)
num_test_samples = num_samples - num_train_samples

# Create a TensorDataset to hold both input and output data
dataset = TensorDataset(input_tensor, output_tensor)

# Split the dataset into training and testing sets
train_dataset, test_dataset = random_split(dataset, [num_train_samples, num_test_samples])

batch_size = 32

# Generate DataLoaders for training and testing set
train_loader = DataLoader(train_dataset, batch_size=batch_size, shuffle=True)
test_loader = DataLoader(test_dataset, batch_size=batch_size, shuffle=False)

input_size = I * J
hidden_size = 64
output_size = J * K

# Create MLP model
model = MLP_model.MLP(input_size, hidden_size, output_size)

# Use MSE as loss function
loss_function = nn.MSELoss()

learning_rate = 0.1

optimizer = torch.optim.Adam(model.parameters(), lr=learning_rate)

num_epochs = 20

# Training
for epoch in range(num_epochs):
    model.train()
    total_loss = 0.0
    
    for inputs, targets in train_loader:
        optimizer.zero_grad()
        
        # Forward pass
        outputs = model(inputs)
        
        # Compute the loss
        loss = loss_function(outputs, targets)

        loss.backward()
        optimizer.step()
        
        total_loss += loss.item()
        
    print(f"Epoch {epoch + 1}/{num_epochs}, Loss: {total_loss / len(train_loader)}")
    
# Testing
model.eval()
with torch.no_grad():
    total_loss = 0.0
    for inputs, targets in test_loader:
        outputs = model(inputs)
        loss = loss_function(outputs, targets)
        total_loss += loss.item()
        
    avg_loss = total_loss / len(test_loader)
    print(f"Test Loss: {avg_loss}")
    
# The following code are used for visualization for one data point
# Generate one date point
data_matrix, centroids_matrix = generate_data.generate_data_matrix_and_centroids_matrix(I, J, K)

data_matrix = data_matrix.astype(np.float32)
centroids_matrix = centroids_matrix.astype(np.float32)

# Plot the points as blue dots, and the centroids as red dots
x_coords = data_matrix[:, 0]
y_coords = data_matrix[:, 1]
plt.scatter(x_coords, y_coords, color='blue', marker='o')

x_coords_center = centroids_matrix[:, 0]
y_coords_center = centroids_matrix[:, 1]
plt.scatter(x_coords_center, y_coords_center, color='red', marker='o')

# Use the trained model to predict the centroids
flattened_data_matrix = data_matrix.reshape(1, -1)
input_tensor = torch.tensor(flattened_data_matrix)
output_tensor = model(input_tensor)

reshaped_output_tensor = output_tensor.view(K, J)
centroids_matrix_pred = reshaped_output_tensor.detach().numpy()

# Plot the predicted centroids as orange dots
x_coords_center_pred = centroids_matrix_pred[:, 0]
y_coords_center_pred = centroids_matrix_pred[:, 1]
plt.scatter(x_coords_center_pred, y_coords_center_pred, color='orange', marker='o')

plt.show()